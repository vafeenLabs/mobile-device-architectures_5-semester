//
//  Concentration.swift
//  Concentration_KKR
//
//  Created by xcode on 18.03.2024.
//

import Foundation

class Concentration {
    var cards = [Card]()
    
    func chooseCard(at index: Int) {
        
    }
    
    init(numberOfPairsOfCards: Int){
        for identifier in 1...numberOfPairsOfCards{
            let card = Card()
            cards += [card, card]
        }
        //TODO:Shuffle the cards
    }
}
