//
//  SettingsController.swift
//  11
//
//  Created by Михаил Лихачев on 08.12.2024.
//  Copyright © 2024 VSU. All rights reserved.
//

import UIKit

class SettingsViewController: UIViewController {

    var currentTheme: Themes = .skull
    var currentDifficulty: Difficulties = .easy
    
    private var areCheatsEnabled = false
    
    @IBOutlet weak var themeSelector: UISegmentedControl!
    
    @IBOutlet weak var difficultySelector: UISegmentedControl!
    
    enum Themes: Int {
        case skull = 0
        case jokerge = 1
        case flags = 2
    }
    
    enum Difficulties: Int
    {
        case easy = 0
        case medium = 1
        case hard = 2
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let themeSegments = ["SKULL","JOKERGE","FLAGS"]
        themeSelector.removeAllSegments()
        for (index,title) in themeSegments.enumerated(){
            themeSelector.insertSegment(withTitle: title, at: index, animated: false)
        }
        themeSelector.selectedSegmentIndex = currentTheme.rawValue;
        
        let difficultySegments = ["HARD","IMPOSSIBLE","NIGHTMARE"]
        difficultySelector.removeAllSegments()
        for (index,title) in difficultySegments.enumerated(){
            difficultySelector.insertSegment(withTitle: title, at: index, animated: false)
        }
        difficultySelector.selectedSegmentIndex = currentDifficulty.rawValue;
    }
    
    @IBAction func startMainScene(_ sender: UIButton) {
        print("load button pressed")
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let destinationVC = storyBoard.instantiateViewController(withIdentifier: "Main")
        as! MainViewController
        
        selectTheme()
        selectDifficulty()
        
        destinationVC.cardCount = getDifficultyCardCount()
        destinationVC.emojies = getThemeEmojies()
        destinationVC.areCheatsEnabled = areCheatsEnabled
        
        if let window = view.window
        {
            window.rootViewController = destinationVC
        }
      
    }
    
    @IBAction func cheatsValueChanged(_ sender: UISwitch) {
        areCheatsEnabled = sender.isOn
    }
    
    @IBAction func randomize(_ sender: UIButton) {
        themeSelector.selectedSegmentIndex = Int.random(in: 0..<themeSelector.numberOfSegments)
        
        difficultySelector.selectedSegmentIndex =
        Int.random(in: 0..<difficultySelector.numberOfSegments)
    }
    
    
    func getDifficultyCardCount() -> Int {
        switch currentDifficulty {
        case .easy:
            return 8
        case .medium:
            return 12
        case .hard:
            return 24
        }
    }
    
    func getThemeEmojies()->[String]
    {
        switch currentTheme {
        case .skull:
            return ["💀","☠️"]
        case .jokerge:
            return ["🤡","👺","🐳","⚡️","🌈","🦄","💋"]
        case .flags:
            return ["🏴‍☠️","🇮🇱","🇧🇾","🇷🇺","🇷🇸","🇸🇰","🇸🇮","🇮🇲"]
            
        }
    }
    

    func selectTheme() {
        switch themeSelector.selectedSegmentIndex
        {
        case 0:
            currentTheme = .skull
        case 1 : currentTheme = .jokerge
        case 2:
            currentTheme = .flags
        default:break
        }
    
    }
    
     func selectDifficulty() {
        switch difficultySelector.selectedSegmentIndex
        {
        case 0:
            currentDifficulty = .easy
        case 1 : currentDifficulty = .medium
        case 2:
            currentDifficulty = .hard
        default:break
        }
    }
   
}
