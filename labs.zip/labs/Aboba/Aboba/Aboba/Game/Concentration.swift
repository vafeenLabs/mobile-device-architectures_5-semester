//
//  Concentration.swift
//  11
//
//  Created by xcode on 28.11.2024.
//  Copyright © 2024 VSU. All rights reserved.
//

import Foundation

struct Concentration{
    var onGameFinished:(()->Void)?
    private(set) public var score: Int = 0
    
   private var helpCount: Int = 0
   private var helpLimit: Int = 1
    
    private var scorePlusDelta: Int = 1
    private var scoreMinusDelta: Int = -2
    
    private (set) var cards=[Card]() //array

    private var indexOfTheOneAndOnlyFaceUpCard: Int? {
        get {
            return cards.indices.filter{cards[$0].isFaceUp}.oneAndOnly
        }
        set {
            for index in cards.indices {
                cards[index].isFaceUp = (index == newValue)
            }
        }
    }

    mutating func chooseCard(at index: Int) {
        assert(cards.indices.contains(index), "Concentration.chooseCard(at: \(index)): choosen index not in the cards")
        if !cards[index].isMatched{
            if let matchIndex = indexOfTheOneAndOnlyFaceUpCard, matchIndex != index {
                if cards[matchIndex] == cards[index] {
                    cards[matchIndex].isMatched = true
                    cards[index].isMatched = true
                    score += scorePlusDelta
                    if isGameFinished()
                    {
                        onGameFinished?()
                    }
                }
                else
                {
                    score = score + scoreMinusDelta
                }
                showCard(at: index)
            } else  {
                indexOfTheOneAndOnlyFaceUpCard = index
            }
        }
        
    }
    
    mutating func hideCard(at index: Int)
    {
        cards[index].isFaceUp = false
    }
    
    mutating func showCard(at index: Int)
    {
        cards[index].isFaceUp = true
    }
    
    func isHelpAvailable() -> Bool
    {
        return helpCount < helpLimit
    }
    
    mutating func tryStartHelp() -> Bool
    {
        if !isHelpAvailable()
        {
            return false
        }
        
        for index in cards.indices
        {
            showCard(at: index)
        }
        helpCount += 1
        
        return true
    }
    
    mutating func endHelp()
    {
        for index in cards.indices
        {
            hideCard(at: index)
        }
    }
    
    func isGameFinished()->Bool{
        for card in cards {
            if !card.isMatched
            {
                return false
            }
        }
        return true
    }

    init(numberOfPairsOfCards: Int){
        assert(numberOfPairsOfCards > 0, "Concentration.init(\(numberOfPairsOfCards)): you must have at least 1 pair of cards")
        for _ in 1...numberOfPairsOfCards{
            let card = Card()
            cards += [card, card] //+2 cards in array
        }
        reshuffle()
    }
    
    mutating func reshuffle()
    {
        for i in 0..<cards.count - 1
        {
            let j = Int.random(in: i..<cards.count)
            if i != j && !cards[i].isMatched && !cards[j].isMatched{
                cards.swapAt(i,j)
            }
        }
    }
}


extension Collection {
    var oneAndOnly: Element? {
        return count == 1 ? first : nil
    }
}
