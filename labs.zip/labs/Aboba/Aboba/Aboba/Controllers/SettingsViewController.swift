//
//  SettingsController.swift
//  11
//
//  Created by Михаил Лихачев on 08.12.2024.
//  Copyright © 2024 VSU. All rights reserved.
//

import UIKit

class SettingsViewController: UIViewController {

    var currentTheme: Themes = .flowers
    var currentDifficulty: Difficulties = .easy

    @IBOutlet weak var themeSelector: UISegmentedControl!
    
    @IBOutlet weak var difficultySelector: UISegmentedControl!
    
    enum Themes: Int {
        case food = 0
        case animals = 1
        case flowers = 2
    }
    
    enum Difficulties: Int
    {
        case easy = 0
        case medium = 1
        case hard = 2
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let themeSegments = ["food","animals","flowers"]
        themeSelector.removeAllSegments()
        for (index,title) in themeSegments.enumerated(){
            themeSelector.insertSegment(withTitle: title, at: index, animated: false)
        }
        themeSelector.selectedSegmentIndex = currentTheme.rawValue;
        
        let difficultySegments = ["easy","medium","hard"]
        difficultySelector.removeAllSegments()
        for (index,title) in difficultySegments.enumerated(){
            difficultySelector.insertSegment(withTitle: title, at: index, animated: false)
        }
        difficultySelector.selectedSegmentIndex = currentDifficulty.rawValue;
    }
    
    @IBAction func startMainScene(_ sender: UIButton) {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let destinationVC = storyBoard.instantiateViewController(withIdentifier: "Main") as! MainViewController
        
        selectTheme()
        selectDifficulty()
        
        destinationVC.cardCount = getDifficultyCardCount()
        destinationVC.emojies = getThemeEmojies()
        
        if let window = view.window
        {
            window.rootViewController = destinationVC
        }
      
    }
    
    @IBAction func randomize(_ sender: UIButton) {
        themeSelector.selectedSegmentIndex = Int.random(in: 0..<themeSelector.numberOfSegments)
        
        difficultySelector.selectedSegmentIndex =
        Int.random(in: 0..<difficultySelector.numberOfSegments)
    }
    
    
    func getDifficultyCardCount() -> Int {
        switch currentDifficulty {
        case .easy:
            return 8
        case .medium:
            return 12
        case .hard:
            return 24
        }
    }
    
    func getThemeEmojies()->[String]
    {
        switch currentTheme {
        case .food:
            return ["🍔","🍕","🌭","🥪","🍖","🍓","🧀"]
        case .animals:
            return ["🐵","🐷","🐳","🦖","🦀","🦄","🐔"]
        case .flowers:
            return ["🌺","🌹","🥀","🌼","🪷","🪻","💐"]
        }
    }
    
    
    func selectTheme() {
        switch themeSelector.selectedSegmentIndex
        {
        case 0:
            currentTheme = .food
        case 1 : currentTheme = .animals
        case 2:
            currentTheme = .flowers
        default:break
        }
    
    }
    
     func selectDifficulty() {
        switch difficultySelector.selectedSegmentIndex
        {
        case 0:
            currentDifficulty = .easy
        case 1 : currentDifficulty = .medium
        case 2:
            currentDifficulty = .hard
        default:break
        }
    }
   
}
