//
//  ViewController.swift
//  11
//
//  Created by xcode on 25.11.2024.
//  Copyright © 2024 VSU. All rights reserved.
//

import UIKit

class MainViewController: UIViewController, UICollectionViewDataSource {
    
    var cardCount : Int = 8
    var emojies : [String] = []
    
    var numberOfPairsOfCards: Int{
        return (cardCount + 1) / 2
    }
    
    private (set) var flipCount = 0 {
        didSet {
            flipCountLabel.text="flips: \(flipCount)"
        }
    }
  
    private lazy var game = Concentration(numberOfPairsOfCards: numberOfPairsOfCards)
    
    var cardButtons: [UIButton] = []

    private var emojiChoices :[String] = []

    private var emoji=[Card: String]()
    
    @IBOutlet weak var restartButton: UIButton!
    
    @IBOutlet private weak var flipCountLabel: UILabel!
    
    @IBOutlet weak var scoreLabel: UILabel!
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    @IBAction private func loadSettingsMenu(_ sender: UIButton) {
        let storyBoard = UIStoryboard(name: "Settings", bundle: nil)
        let destinationVC = storyBoard.instantiateViewController(withIdentifier: "Settings")
        
        if let window = view.window
        {
            window.rootViewController = destinationVC
        }
    }
    
    @objc private func touchCard(_ sender: UIButton) {
        flipCount += 1
        sender.isEnabled = false
        if let cardNumber = cardButtons.firstIndex(of:sender){
            game.chooseCard(at: cardNumber)
            updateScore()
            updateViewFromModel()
        } else{
            print("choosen card was not in cardButtons")
        }
    }
    
    
    @IBAction private func reshuffleCards(_ sender: UIButton) {
        game.reshuffle()
        updateViewFromModel()
                
    }
    
    @IBAction func showCardsForSec(_ sender: UIButton) {
        if !game.tryStartHelp()
        {
            return
        }
        updateViewFromModel()
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0)
        {
            self.game.endHelp()
            self.updateViewFromModel()
        }
        if !game.isHelpAvailable()
        {
            sender.isEnabled = false
            sender.isHidden = true
        }
      
    }
    
    @IBAction func restartGame(_ sender: UIButton) {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let destinationVC = storyBoard.instantiateViewController(withIdentifier: "Main")
        as! MainViewController
        
        destinationVC.cardCount = cardCount
        destinationVC.emojies = emojies
    
        
        if let window = view.window
        {
            window.rootViewController = destinationVC
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.dataSource = self
        game.onGameFinished = {[weak self]in
            self?.handleFinishGame()}
    }
    
     func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return cardCount
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ButtonCell", for: indexPath)
         let button = cell.viewWithTag(1) as! UIButton
           setCardButtonToDefault(button: button)
        button.addTarget(self, action: #selector(touchCard(_:)), for: .touchUpInside)
          button.removeTarget(self, action: #selector(touchCard(_:)), for: .touchDown)
           
            cardButtons.append(button)
      
        return cell

    }
    
    private func updateScore()
    {
        scoreLabel.text = "score: \(game.score)"
    }
    
    private func handleFinishGame()
    {
        for button in cardButtons {
            button.isHidden = true
            button.isEnabled = false
        }
        collectionView.isHidden = true
        restartButton.isHidden = false
        restartButton.isEnabled = true
        
    }
    
    private func updateViewFromModel(){
            for index in cardButtons.indices {
                let button = cardButtons[index]
                let card = game.cards[index]
                if card.isFaceUp{
                    button.setTitle(emoji(for: card), for: UIControl.State.normal)
                    button.backgroundColor = UIColor.white
                } else{
                    button.setTitle("",for: UIControl.State.normal)
                    if card.isMatched
                    {
                        button.isHidden = true
                        button.isEnabled = false
                    }
                    else
                    {
                        setCardButtonToDefault(button: button)
                        button.isEnabled = true
                    }

                }
            }
        }
    
    private func setCardButtonToDefault(button: UIButton)
    {
        button.setTitle("", for: .normal)
        button.backgroundColor = UIColor.systemMint
    }

    private func emoji(for card:Card)->String{
        if emojiChoices.count <= 0 {
            
            for emj in emojies
            {
                emojiChoices.append(emj)
            }
        }
        if emoji[card] == nil {
            emoji[card]=emojiChoices.remove(at: Int.random(in: 0..<emojiChoices.count))
        }
        return emoji[card] ?? "?"
    }

    private func flipCard(withEmoji emoji:String, on button:UIButton){
        if button.currentTitle==emoji{
           setCardButtonToDefault(button: button)
        } else{
            button.setTitle(emoji, for:UIControl.State.normal)
            button.backgroundColor = UIColor.white
        }
    }
}

